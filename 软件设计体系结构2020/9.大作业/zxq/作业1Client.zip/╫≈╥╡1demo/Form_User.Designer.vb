﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_User
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.userInfo = New System.Windows.Forms.Label()
        Me.ifprocess = New System.Windows.Forms.Label()
        Me.deal = New System.Windows.Forms.Button()
        Me.listview1 = New System.Windows.Forms.ListView()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'userInfo
        '
        Me.userInfo.AutoSize = True
        Me.userInfo.Location = New System.Drawing.Point(12, 32)
        Me.userInfo.Name = "userInfo"
        Me.userInfo.Size = New System.Drawing.Size(62, 18)
        Me.userInfo.TabIndex = 0
        Me.userInfo.Text = "Label1"
        '
        'ifprocess
        '
        Me.ifprocess.AutoSize = True
        Me.ifprocess.Location = New System.Drawing.Point(12, 125)
        Me.ifprocess.Name = "ifprocess"
        Me.ifprocess.Size = New System.Drawing.Size(62, 18)
        Me.ifprocess.TabIndex = 1
        Me.ifprocess.Text = "Label1"
        '
        'deal
        '
        Me.deal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.deal.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.deal.Location = New System.Drawing.Point(477, 251)
        Me.deal.Name = "deal"
        Me.deal.Size = New System.Drawing.Size(136, 46)
        Me.deal.TabIndex = 2
        Me.deal.Text = "处理"
        Me.deal.UseVisualStyleBackColor = True
        '
        'listview1
        '
        Me.listview1.Location = New System.Drawing.Point(2, 150)
        Me.listview1.Name = "listview1"
        Me.listview1.Size = New System.Drawing.Size(457, 237)
        Me.listview1.TabIndex = 3
        Me.listview1.UseCompatibleStateImageBehavior = False
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(477, 182)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(135, 45)
        Me.btnUpdate.TabIndex = 4
        Me.btnUpdate.Text = "刷新"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'Form_User
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(644, 390)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.listview1)
        Me.Controls.Add(Me.deal)
        Me.Controls.Add(Me.ifprocess)
        Me.Controls.Add(Me.userInfo)
        Me.Name = "Form_User"
        Me.Text = "Form_User"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents userInfo As System.Windows.Forms.Label
    Friend WithEvents ifprocess As System.Windows.Forms.Label
    Friend WithEvents deal As System.Windows.Forms.Button
    Friend WithEvents listview1 As System.Windows.Forms.ListView
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
End Class
