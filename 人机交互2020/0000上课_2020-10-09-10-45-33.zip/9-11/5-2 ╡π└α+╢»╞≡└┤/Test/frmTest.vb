﻿Imports System.IO

Public Class frmTest
   
    Dim p As clsPoint
    Private Sub frmTest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        p = New clsPoint(150, 150)
        tmTicker.Interval = 100
        tmTicker.Enabled = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        tmTicker.Enabled = Not tmTicker.Enabled
    End Sub

    Private Sub tmTicker_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmTicker.Tick
        Dim dx As Integer = 2 * (Rnd() - 0.5), dy As Integer = 2 * (Rnd() - 0.5)
        p.Move(dx * 5, dy * 5)
        Dim g As Graphics = picCanvas.CreateGraphics
        p.Draw(g)
    End Sub
End Class
