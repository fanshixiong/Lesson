﻿Imports System.IO

Public Class frmTest
   
    Dim p As clsPoint
    Private Sub frmTest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        p = New clsPoint(100, 100)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim g As Graphics = picCanvas.CreateGraphics
        p.Draw(g)
        p.Move(10, 0)
        p.Draw(g)
        p.Move(0, 10)
        p.Draw(g)
        p.Move(10, 0)
        p.Draw(g)
    End Sub
End Class
