package sample.DataProcess;

public class BTest {
    /*public static void main(String[] args){
        //"ABCDE#FG#####HI"
        String str = "ABCDE#FG#####HI";
        String string1[] = dataProcess.getSTNodesvalue(str);
        String string2[] = dataProcess.getCom(str);
        String string3[] = dataProcess.getPre(str,"pre");
        String string4[] = dataProcess.getPost(str,"pre");
        for(int i=0;i<string4.length;i++){
            System.out.println(string4[i]);
        }
    }*/
}
