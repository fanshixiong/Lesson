package com.tmall.pokemon.bulbasaur.task.constant;

/**
 * User:  yunche.ch ... (ว ˙o˙)ง
 * Date: 14-12-17
 * Time: 下午3:15
 */


public class ParticipationConstant {

    public static final String TYPE_ORI_USER = "oriUser";
}
