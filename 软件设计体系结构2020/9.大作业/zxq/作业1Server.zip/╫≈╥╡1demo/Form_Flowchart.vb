﻿Public Class Form_Flowchart
    Dim g As Graphics
    Dim cRectangle As clsRectangle
    Dim cEllipse As clsEllipse
    Dim CLine As clsLine
    Dim cEllipses As New List(Of clsEllipse)
    Dim cDiamond As clsDiamond
    Dim steps As List(Of Eachstep)
    Private flag As Boolean = False

    Public Sub SetInfo(ByVal steps As List(Of Eachstep))
        Me.steps = steps
    End Sub

    Public Sub Redraw()
        g = Me.CreateGraphics
        g.Clear(Me.BackColor)
        cEllipses.Clear()
        '画开始矩形
        cRectangle = New clsRectangle(New Point(Me.Width / 2 - 30, 5), New Point(Me.Width / 2 + 30, 40))
        cRectangle.Draw(g)
        g.DrawString("开始", New Font("Aril", 12), Brushes.Black, New Point(Me.Width / 2 - 20, 15))
        '画椭圆
        Dim i As Integer
        For i = 0 To steps.Count - 1 Step 1
            Dim ss As List(Of Eachstepitem) = steps(i).eachsteplist
            Dim perX = Me.Width / (ss.Count + 1)
            Dim perY = (Me.Height - 40 * 2) / (steps.Count + 1)
            For j As Integer = 0 To ss.Count - 1 Step 1
                cEllipse = New clsEllipse(New Point(perX * (j + 1) - 50, perY * (i + 1) - 30), New Point(perX * (j + 1) + 50, perY * (i + 1) + 30))
                cEllipse.Draw(g, ss(j))
                cEllipses.Add(cEllipse)
            Next
        Next
        '画结束矩形
        cRectangle = New clsRectangle(New Point(Me.Width / 2 - 30, Me.ClientSize.Height - 40), New Point(Me.Width / 2 + 30, Me.ClientSize.Height - 5))
        cRectangle.Draw(g)
        g.DrawString("结束", New Font("Aril", 12), Brushes.Black, New Point(Me.Width / 2 - 20, Me.ClientSize.Height - 30))
        '画连线
        '开始矩形到第一个椭圆的连线
        Dim sp = New Point(Me.Width / 2, 40)
        Dim ep = New Point((cEllipses(0).sp.X + cEllipses(0).ep.X) / 2, cEllipses(0).sp.Y)
        CLine = New clsLine(sp, ep)
        CLine.Draw(g)
        '椭圆之间的连线
        Dim m As Integer = 0
        Dim n As Integer = 0        '记录椭圆个数,0为起点!!
        For i = 0 To steps.Count - 2 Step 1
            '如果i+1行只有一个元素,直接跟i行元素连线
            n = m + (steps(i).eachsteplist).Count
            If ((steps(i + 1).eachsteplist).Count = 1) Then
                For j As Integer = 0 To (steps(i).eachsteplist).Count - 1 Step 1
                    sp = New Point((cEllipses(m).sp.X + cEllipses(m).ep.X) / 2, cEllipses(m).ep.Y)
                    Dim mp = New Point((cEllipses(n).sp.X + cEllipses(n).ep.X) / 2, (cEllipses(m).ep.Y + cEllipses(n).sp.Y) / 2)
                    ep = New Point((cEllipses(n).sp.X + cEllipses(n).ep.X) / 2, cEllipses(n).sp.Y)
                    CLine = New clsLine(sp, mp)
                    CLine.Draw(g)
                    CLine = New clsLine(mp, ep)
                    CLine.Draw(g)
                    m += 1
                Next
            Else
                Dim midup = New Point((cEllipses(m).sp.X + cEllipses(n - 1).ep.X) / 2, (cEllipses(m).ep.Y + cEllipses(n).sp.Y) / 2 - 5)
                Dim middown = New Point((cEllipses(m).sp.X + cEllipses(n - 1).ep.X) / 2, (cEllipses(m).ep.Y + cEllipses(n).sp.Y) / 2 + 5)
                '第i行的若干元素，先从源点画到mid
                For j As Integer = 0 To (steps(i).eachsteplist).Count - 1
                    sp = New Point((cEllipses(m).sp.X + cEllipses(m).ep.X) / 2, cEllipses(m).ep.Y)
                    CLine = New clsLine(sp, midup)
                    CLine.Draw(g)
                    m += 1
                Next
                cDiamond = New clsDiamond(midup, middown)
                cDiamond.Draw(g)
                '从mid画到第i+1行的各元素
                For j As Integer = 0 To (steps(i + 1).eachsteplist).Count - 1 Step 1
                    ep = New Point((cEllipses(n).sp.X + cEllipses(n).ep.X) / 2, cEllipses(n).sp.Y)
                    CLine = New clsLine(middown, ep)
                    CLine.Draw(g)
                    n += 1
                Next
                n -= 1
            End If
        Next
        '最后一行椭圆到结束矩形的连线
        m = n - steps(i).eachsteplist.Count + 1
        For j As Integer = 0 To (steps(i).eachsteplist).Count - 1 Step 1
            sp = New Point((cEllipses(m).sp.X + cEllipses(m).ep.X) / 2, cEllipses(m).ep.Y)
            Dim mp = New Point(Me.Width / 2, (cEllipses(m).ep.Y + Me.ClientSize.Height - 40) / 2)
            ep = New Point(Me.Width / 2, Me.ClientSize.Height - 40)
            CLine = New clsLine(sp, mp)
            CLine.Draw(g)
            CLine = New clsLine(mp, ep)
            CLine.Draw(g)
            m += 1
        Next

    End Sub

    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click
        Redraw()
        flag = True
    End Sub

    Private Sub Form_Flowchart_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        If (flag) Then
            Redraw()
        End If
    End Sub

End Class