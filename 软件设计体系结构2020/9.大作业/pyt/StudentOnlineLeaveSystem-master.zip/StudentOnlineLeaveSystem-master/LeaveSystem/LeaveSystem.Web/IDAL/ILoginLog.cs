﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LeaveSystem.Web.IDAL
{
    public interface ILoginLog : IEntity<int>
    {
    }
}