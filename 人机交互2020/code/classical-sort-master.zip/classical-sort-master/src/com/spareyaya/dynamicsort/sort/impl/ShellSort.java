package com.spareyaya.dynamicsort.sort.impl;

/**
 * Created on 2017/4/17.
 *
 * @author spareyaya.
 */
public class ShellSort extends SortAdapter {
    @Override
    public void sort(int[] unsortedArray) {
        sortDesc(unsortedArray);
    }

    @Override
    public void sortDesc(int[] unsortedArray) {

    }

    @Override
    public void sortInc(int[] unsortedArray) {

    }
}
