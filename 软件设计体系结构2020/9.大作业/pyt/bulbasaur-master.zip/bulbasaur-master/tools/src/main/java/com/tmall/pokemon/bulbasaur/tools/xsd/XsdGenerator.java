package com.tmall.pokemon.bulbasaur.tools.xsd;

/**
 * Created by IntelliJ IDEA.
 * User: guichen - anson
 * Date: 13-1-12
 */
public class XsdGenerator {
	public static void main(String[] args) {

	}
}
