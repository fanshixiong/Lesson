﻿Public Class clsRectangle
    Public sp, ep As Point

    Public Sub New(ByVal sp As Point, ByVal ep As Point)
        Me.sp = sp : Me.ep = ep
    End Sub

    Public Sub Draw(ByVal g As Graphics)
        '画矩形
        g.DrawRectangle(Pens.Black, sp.X, sp.Y, ep.X - sp.X, ep.Y - sp.Y)
    End Sub
End Class
