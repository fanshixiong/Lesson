# JavaFXTest
JavaFX，树，排序算法可视化

使用的Java第三方库GraphViz实现二叉树等静态可视化

使用JavaFX中的BarChart以及Timeline实现排序算法动态可视化

未完待续...

部分实现结果如下

二叉树的静态可视化：

![Image text](https://github.com/fanghuiX/JavaFXTest/blob/master/tree.gif)

冒泡排序可视化：

![Image text](https://github.com/fanghuiX/JavaFXTest/blob/master/bobblesort.gif)

排序算法比较可视化：


![Image text](https://github.com/fanghuiX/JavaFXTest/blob/master/sortcompare.gif)