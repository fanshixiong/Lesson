package com.tmall.pokemon.bulbasaur.schedule.vo;

/**
 * User:  yunche.ch ... (ว ˙o˙)ง
 * Date: 17/4/13
 * Time: 下午4:40
 */
public class DayOfMonth extends Interval {
    @Override
    public int calcDelay(int param) {
        return 0;
    }
}
