﻿Public Class Form_apply
    Private num As Integer
    Private Sub Form_apply_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        numeric.Minimum = 0
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        num = numeric.Value
        Me.Close()
    End Sub

    Public Function GetNum() As Integer
        Return num
    End Function
End Class