﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Text
Public Class Form_UserLogin
    Private idens As List(Of String)
    Private frm3 As Form_User
    Private strs As String = Nothing
    Private s2 As Socket
    Private localEndPoint2 As IPEndPoint

    Private Sub Form_UserLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        s2 = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) '使用TCP协议
        localEndPoint2 = New IPEndPoint(IPAddress.Parse("127.0.0.1"), 8086) '指定IP和Port

        '客户端开启时就要与服务器建立连接，并接收数据，
        SendData("r")
        Threading.Thread.Sleep(10)
        Dim strs = RecvData(s2, localEndPoint2) '通过套接口1，接收多个身份项
        Dim str() = AnaSingleStr(strs) '分隔多个身份
        idens = New List(Of String)
        For i As Integer = 0 To str.Count - 1 Step 1
            idenbox.Items.Add(str(i))
            idens.Add(str(i))
        Next
    End Sub

    '使用套接口2发送数据---建立连接并发送数据,
    Public Sub SendData(ByVal str As String)
        Try
            s2 = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) '使用TCP协议
            localEndPoint2 = New IPEndPoint(IPAddress.Parse("127.0.0.1"), 8086) '指定IP和Port
            s2.Connect(localEndPoint2)
            s2.Send(Encoding.Unicode.GetBytes(str))
        Catch ex As Exception

        End Try
    End Sub

    '传入套接口接收数据, 建立连接并接收数据,并返回接收到的字符串
    Public Function RecvData(ByRef s As Socket, ByRef localEndPoint As IPEndPoint) As String
        Try
            Dim bytes(1024) As Byte
            's.Connect(localEndPoint) '试一试，大概前面发送时候，申请连接了，这里就不用重新连了
            Dim n As Integer = s.Receive(bytes) '接收数据
            Dim b() As Byte = TransInfo(bytes, n) '将byte数组转换为正确长度的字符串
            strs = Encoding.Unicode.GetString(b) '接收客户端传过来的用户信息

        Catch ex As Exception
        Finally
            s.Close() '先发送后接收，接收完成后，这一次交互就结束了，所以套接口可以关闭
        End Try
        Return strs
    End Function
    
    '选择登录
    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim id As String = idbox.Text
        Dim pw As String = pwbox.Text
        Dim iden As String = idenbox.Text
        If (id = "" Or pw = "" Or iden = "") Then
            MsgBox("不接受空值！")
        Else
            Dim userinfo As String = "1" + id + "-" + pw + "-" + iden '1标识说明是发送登录信息
            SendData(userinfo) '将登录信息发送给服务器
            Dim mstr = RecvData(s2, localEndPoint2) '接收登录后的返回信息
            If (mstr(0) = "n") Then
                MsgBox("账号或密码错误，请重新填写")
            Else
                Dim str() As String = mstr.Split(",")
                frm3 = New Form_User()
                frm3.SetInfo(id, iden, pw, str) '将该用户是否要处理事项和事项队列传过去，
                frm3.ShowDialog()
            End If
        End If
    End Sub

    '选择注册，需要向服务器发送数据
    Private Sub btnRegister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRegister.Click
        Dim id As String = idbox.Text
        Dim pw As String = pwbox.Text
        Dim iden As String = idenbox.Text
        If (id = "" Or pw = "" Or iden = "") Then
            MsgBox("不接受空值！")
        Else
            Dim userinfo As String = "0" + id + "-" + pw + "-" + iden '0标识说明是发送注册信息
            SendData(userinfo) '将注册信息发送给服务器
            Dim flag = RecvData(s2, localEndPoint2) '接收登录后的返回信息
            'MsgBox(flag, MsgBoxStyle.OkOnly, "服务器返回信息")
            If (flag(0) = "y") Then
                MsgBox("注册成功")
            Else
                MsgBox("该用户已存在")
            End If
            idbox.Text = ""
            pwbox.Text = ""
            idenbox.Text = ""
        End If
    End Sub
End Class