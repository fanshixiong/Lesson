﻿Public Class clsEllipse
    Public sp, ep As Point

    Public Sub New(ByVal sp As Point, ByVal ep As Point)
        Me.sp = sp : Me.ep = ep
    End Sub

    Public Sub Draw(ByVal g As Graphics, ByVal item As Eachstepitem)
        '画椭圆
        g.DrawEllipse(Pens.Black, sp.X, sp.Y, ep.X - sp.X, ep.Y - sp.Y)
        '写字
        Dim fontsize = 100 / (item.identity.Length + item.operate.Length + 1) / 1.5
        If Len(item.constraint) > 0 Then
            'g.DrawString(item.constraint, New Font("Aril", 8), Brushes.Red, New Point(sp.X + (ep.X - sp.X) / 6, (ep.Y - sp.Y) / 4 + sp.Y))
            g.DrawString(item.constraint, New Font("Aril", 8), Brushes.Red, New Point((sp.X + ep.X) / 2 - item.constraint.Length / 2 * 8 * 1.5, (ep.Y - sp.Y) / 4 + sp.Y))
            g.DrawString(vbCrLf + item.identity + ":" + item.operate, New Font("Aril", fontsize), Brushes.Black, New Point(sp.X + 2, (ep.Y - sp.Y) / 3 + sp.Y))
        Else
            g.DrawString(item.identity + ":" + item.operate, New Font("Aril", fontsize), Brushes.Black, New Point(sp.X + 2, (ep.Y - sp.Y) / 3 + sp.Y))
        End If
    End Sub
End Class
