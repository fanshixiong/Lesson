﻿Module textpoc
    Public Function TransInfo(ByVal bytes() As Byte, ByVal n As Integer) As Byte()
        '----------------定义时候下标从0开始的
        Dim b(n - 1) As Byte
        For i As Integer = 0 To n - 1 Step 1
            b(i) = bytes(i)
        Next
        Return b
    End Function

    '解析接收到的多行拼接起来的字符串,返回多行字符串数组
    Public Function AnaMultiStr(ByVal mstr As String) As String()
        Dim sstrs() As String = mstr.Split(",")
        Return sstrs
    End Function

    '解析多个数据项拼接的一行字符串，返回多个数据项
    Public Function AnaSingleStr(ByVal sstr As String) As String()
        Dim strs() As String = sstr.Split("-")
        Return strs
    End Function

End Module
