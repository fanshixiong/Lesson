﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LeaveSystem.Web.Infrastructure
{
    public enum Permissions
    {
        查看用户,
        新增用户,
        修改用户,
        删除用户
    }
}