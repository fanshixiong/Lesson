﻿Imports System.ComponentModel
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Public Class Form1
    Dim frm2 As Form_Construct '构建模板页面
    Dim frm3 As Form_Process '显示流程页面
    Dim kinds As String '给客户端传递身份类别用
    Dim users As List(Of clsUser) '记录系统已注册用户
    Dim steps As List(Of Eachstep)
    Dim applications As List(Of clsApplicant) = New List(Of clsApplicant) '存放所有申请信息
    Dim mstrs As String = Nothing
    Dim s1 As Socket = Nothing '用于发送初始化信息
    Dim s2 As Socket = Nothing '用于接收登录或注册信息，并执行某操作
    Dim t1 As Thread '对应s1
    Dim t2 As Thread '对应s2
    Dim write1 As System.IO.StreamWriter = New System.IO.StreamWriter("users.txt", False, System.Text.Encoding.UTF8)
    Dim write2 As System.IO.StreamWriter = New System.IO.StreamWriter("applications.txt", False, System.Text.Encoding.UTF8)

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        users = New List(Of clsUser)
    End Sub

    Private Sub btnConstruct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConstruct.Click
        frm2 = New Form_Construct()
        frm2.ShowDialog()
        kinds = frm2.GetKind() '获取身份类别
        steps = frm2.Getsteps() '获取模板数组
        'MsgBox(kinds)
    End Sub

    '解析多个数据项拼接的一行字符串，返回多个数据项
    Public Function AnaSingleStr(ByVal sstr As String) As String()
        Dim strs() As String = sstr.Split("-")
        Return strs
    End Function

    '之二：客户端发送登录或者注册信息, 需要给客户发信息, 或者响应注册请求
    Public Sub ExchangeData()
        Dim strs As String = Nothing
        s2 = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) '使用TCP协议
        Dim localEndPoint As New IPEndPoint(IPAddress.Parse("127.0.0.1"), 8086) '指定IP和Port
        s2.Bind(localEndPoint) '绑定到该Socket
        s2.Listen(100) '侦听，最多接收100个连接
        Dim bytes(1024) As Byte '定义缓冲区

        While (True)
            Dim ss As Socket = s2.Accept() '与客户端登录页面连接
            Dim n As Integer = ss.Receive(bytes) '接收数据,--------------一定要返回接收到的字节数
            Dim b() As Byte = TransInfo(bytes, n) '将byte数组转换为正确长度的字符串
            strs = Encoding.Unicode.GetString(b) '接收客户端传过来的用户信息
            If (strs(0) = "r") Then '开始时候发送身份类别
                ss.Send(Encoding.Unicode.GetBytes(kinds))
            End If
            If (strs(0) = "0") Then '表示用户申请注册
                strs = strs.Substring(1)
                Dim str() As String = AnaSingleStr(strs) '分割传输过来的字符串
                '检查是否存在该用户
                If (Not IsPresent(str)) Then
                    Dim newuser As clsUser = New clsUser(str(0), str(1), str(2))
                    users.Add(newuser)
                    ss.Send(Encoding.Unicode.GetBytes("y"))
                Else
                    ss.Send(Encoding.Unicode.GetBytes("n"))
                End If
            ElseIf (strs(0) = "1") Then '表示用户申请登录
                strs = strs.Substring(1)
                Dim str() As String = AnaSingleStr(strs) '----------用户信息
                If (Not IsPresent(str)) Then '登录用户不存在
                    ss.Send(Encoding.Unicode.GetBytes("n"))
                Else
                    '申请人和审批人收到的信息不一样
                    If (str(2) = steps(0).eachsteplist(0).identity) Then
                        mstrs = OrgAppliInfo(str(0)) '组织申请者信息
                    Else
                        mstrs = OrgApproInfo(str(2))
                    End If
                    ss.Send(Encoding.Unicode.GetBytes(mstrs))
                End If
            End If
            If (strs(0) = "i") Then '---------------------------用户申请
                strs = strs.Substring(1)
                Dim str() As String = strs.Split("-")
                AddApplicants(str(0), str(1))
                mstrs = OrgAppliInfo(str(0))
                ss.Send(Encoding.Unicode.GetBytes(mstrs))
            ElseIf (strs(0) = "d") Then '------------------------用户审批
                Dim s As String = strs.Substring(2)
                Dim str() As String = s.Split("-")
                If (strs(1) = "1") Then '审核通过,流程进行下去
                    DeleteAppliReviewer(str(0), str(1), str(2)) '------
                ElseIf (strs(1) = "0") Then '审核不通过
                    RefuseApplication(str(0), str(1), str(2)) '拒绝申请
                End If
                mstrs = OrgApproInfo(str(0))
                ss.Send(Encoding.Unicode.GetBytes(mstrs))
            End If

        End While

    End Sub

    '这一步很重要！不然接收到的字符串由于是由固定长度的bytes数组转换的，后面会跟着一大串空字符
    Public Function TransInfo(ByVal bytes() As Byte, ByVal n As Integer) As Byte()
        '----------------定义时候下标从0开始的
        Dim b(n - 1) As Byte
        For i As Integer = 0 To n - 1 Step 1
            b(i) = bytes(i)
        Next
        Return b
    End Function

    '查询某学号、密码、身份是否存在
    Public Function IsPresent(ByVal str() As String) As Boolean
        If (users.Count = 0) Then
            Return False
        Else
            For i As Integer = 0 To users.Count - 1 Step 1
                If (users(i).GetID() = str(0) And users(i).GetPassword = str(1) And users(i).GetIden = str(2)) Then
                    Return True
                End If
            Next
        End If
        Return False
    End Function

    '当初始有申请权利的身份登录时，返回：操作+(n+待审批人+当列表为空时，b为0是夭折，b为1是通过)
    Public Function OrgAppliInfo(ByVal id As String) As String
        Dim mstrs As String = Nothing
        mstrs += steps(0).eachsteplist(0).operate '操作类型
        mstrs += ","
        For i As Integer = 0 To applications.Count - 1 Step 1 '寻找申请列表里的id相同的项
            If (applications(i).GetID() = id) Then
                Dim b As String = "1"
                If (applications(i).GetStep() + 1 < steps.Count) Then '当身份列表为空时，判断申请是通过了，还是半路夭折
                    b = "0"
                End If
                '身份列表为空时，根据b判断是超出范围还是通过了；身份列表不为空时，根据flag判断是待...审批还是...不通过
                mstrs += applications(i).GetNum() + "-" + applications(i).GetIdensToString() + "-" + b + "-" + CStr(applications(i).GetFlag()) '
                mstrs += ","
            End If
        Next
        Return mstrs
    End Function


    '有审批权利的人登录时，返回：申请人id+申请天数n
    Public Function OrgApproInfo(ByVal iden As String) As String
        Dim mstrs As String = Nothing
        For i As Integer = 0 To steps.Count - 1 Step 1
            For j As Integer = 0 To (steps(i).eachsteplist).Count - 1 Step 1
                Dim item = steps(i).eachsteplist(j)
                If (item.identity = iden) Then
                    mstrs = item.operate
                End If
            Next
        Next
        mstrs += ","
        For i As Integer = 0 To applications.Count - 1 Step 1
            If (applications(i).IsApparent(iden) And applications(i).GetFlag()) Then
                mstrs += applications(i).GetID() + "-" + applications(i).GetNum()
                mstrs += ","
            End If
        Next
        Return mstrs
    End Function

    '新增申请，参数：申请者id+数目num
    Public Sub AddApplicants(ByVal id As String, ByVal num As String)
        Dim idenlist As List(Of String) = New List(Of String)
        Dim items As List(Of Eachstepitem) = steps(1).eachsteplist
        If (items.Count = 1) Then '单支节点的话，不用判断范围直接添加进流程
            idenlist.Add(items(0).identity)

        Else
            For i As Integer = 0 To items.Count - 1 Step 1 '分支节点
                If (IsInNumrange(CInt(num), items(i).constraint)) Then '在范围内的加进去
                    idenlist.Add(items(i).identity)
                End If
            Next

        End If
        Dim ss As Integer
        If (idenlist.Count = 0) Then
            ss = 0
        Else
            ss = 1
        End If
        Dim applicant As clsApplicant = New clsApplicant(id, CInt(num), idenlist, ss) '新增申请,idenlist为空则不进入第一层
        applications.Add(applicant) '加入申请数组
    End Sub

    '审批人拒绝申请'--------------
    Public Sub RefuseApplication(ByVal iden As String, ByVal id As String, ByVal num As String)
        Dim j As Integer
        For i As Integer = 0 To applications.Count - 1 Step 1
            Dim a = applications(i)
            If (id = a.GetID And num = a.GetNum() And a.IsApparent(iden)) Then
                j = i '找到该申请项的位置
                applications(i).DeleteIden(iden)
                Exit For
            End If
        Next
        Dim idenlists As List(Of String) = New List(Of String)
        idenlists.Add(iden)
        applications(j).ResetIdens(idenlists)
        applications(j).SetFlag() '设置该申请项为被拒绝
    End Sub

    '审批人同意申请-------------------------------------------------------------------------------------------------------
    Public Sub DeleteAppliReviewer(ByVal iden As String, ByVal id As String, ByVal num As String)
        Dim j As Integer
        For i As Integer = 0 To applications.Count - 1 Step 1
            Dim a = applications(i)
            If (id = a.GetID And num = a.GetNum() And a.IsApparent(iden)) Then
                j = i
                applications(i).DeleteIden(iden)
                Exit For
            End If
        Next
        If (applications(j).IsEmpty()) Then '如果该层均审批完毕，则跳到下层
            If (applications(j).GetStep() < steps.Count - 1) Then '如果模板下层还有结点，则继续转交下一层；否则结束
                Dim idenlist As List(Of String) = New List(Of String)
                Dim items As List(Of Eachstepitem) = steps(applications(j).GetStep() + 1).eachsteplist '模板中下一层节点
                If (items.Count = 1) Then '单支节点的话，不用判断范围直接添加进流程
                    idenlist.Add(items(0).identity)
                Else
                    For i As Integer = 0 To items.Count - 1 Step 1 '分支节点
                        If (IsInNumrange(CInt(num), items(i).constraint)) Then '在范围内的加进去
                            idenlist.Add(items(i).identity)
                        End If
                    Next
                End If
                applications(j).ResetIdens(idenlist)
                If (idenlist.Count > 0) Then '只有当真正进入到下一层的模板，即下一层有内容的时候，才给步骤数加1
                    applications(j).AddStep()
                End If

            End If
        End If
    End Sub



    Public Function IsInNumrange(ByVal num As Integer, ByVal constraint As String) As Boolean
        Dim s() As String = constraint.Split("~")
        If (num >= CInt(s(0)) And num <= CInt(s(1))) Then
            Return True
        End If
        Return False
    End Function

    '建立新的线程
    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        t2 = New Thread(AddressOf ExchangeData) '建立新的线程
        t2.Start() '启动线程
        btnStart.Enabled = False
        btnConstruct.Enabled = False
    End Sub

    '中止线程
    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        Try
            s2.Close() '关闭socket
            t2.Abort() '中止线程
        Catch ex As Exception
        Finally
            btnStart.Enabled = True '启用线程
        End Try
    End Sub

    '关闭窗口
    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Try
            s2.Close()
            t2.Abort()
            Dim sstr As String = Nothing
            For i As Integer = 0 To users.Count - 1 Step 1
                sstr = users(i).GetID() + " " + users(i).GetPassword + " " + users(i).GetIden()
                write1.WriteLine(sstr)
                write1.Flush()
            Next
            For i As Integer = 0 To applications.Count - 1 Step 1
                Dim s As String = Nothing
                If (applications(i).IsEmpty()) Then
                    If (applications(i).GetStep() + 1 < steps.Count) Then
                        s = "申请不在范围内"
                    Else
                        s = "申请通过"
                    End If
                Else
                    If (applications(i).GetFlag()) Then
                        s = "待" + applications(i).GetIdensToString + "审批"
                    Else
                        s = applications(i).GetIdensToString + "审批不通过"
                    End If
                End If
                sstr = applications(i).GetID() + " " + applications(i).GetNum() + " " + s
                write2.WriteLine(sstr)
                write2.Flush()
            Next
            write1.Close()
            write2.Close()

        Catch ex As Exception
        End Try
    End Sub

    '后台显示流程信息
    Private Sub btnMainLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMainLogin.Click
        frm3 = New Form_Process()
        frm3.SetInfo(applications, steps.Count)
        frm3.ShowDialog()
    End Sub
End Class
