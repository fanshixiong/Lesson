package com.tmall.pokemon.bulbasaur.schedule.job;


/**
 * User: yunche.ch
 * Date: 13-11-1
 * Time: 下午4:04
 */
public interface Job {
    void doJob();
}
