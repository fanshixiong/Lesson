package com.flow.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author 蔡小蔚
 */
@Configuration
@ComponentScan(basePackages = {"com.flow"})
public class MqConfig {

}
