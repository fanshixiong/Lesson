/*
package sample;

import javafx.stage.Stage;

public class start {
    public static void main(String[] args) throws Exception{
        Main.getInstance().start(new Stage());
    }
}
*/
