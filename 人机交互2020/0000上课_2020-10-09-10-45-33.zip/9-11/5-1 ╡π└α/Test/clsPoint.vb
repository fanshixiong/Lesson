﻿Public Class clsPoint
    Private x As Single, y As Single
    Private lastx As Single, lasty As Single

    Public Sub New(ByVal x As Single, ByVal y As Single)
        Me.x = x : Me.y = y
        lastx = x : lasty = y
    End Sub
    Sub Move(ByVal dx As Single, ByVal dy As Single)
        x += dx : y += dy
    End Sub
    Sub Draw(ByVal g As Graphics)
        g.DrawLine(Pens.Black, lastx, lasty, x, y)
        lastx = x : lasty = y
    End Sub
End Class
