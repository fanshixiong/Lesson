﻿Public Class clsDiamond
    Public sp, ep As Point

    Public Sub New(ByVal sp As Point, ByVal ep As Point)
        Me.sp = sp : Me.ep = ep
    End Sub

    Public Sub Draw(ByVal g As Graphics)
        '画菱形
        g.DrawLine(Pens.Black, sp.X, sp.Y, sp.X - 8, sp.Y + 5)          '上左
        g.DrawLine(Pens.Black, sp.X, sp.Y, sp.X + 8, sp.Y + 5)          '上右
        g.DrawLine(Pens.Black, sp.X - 8, sp.Y + 5, ep.X, ep.Y)          '下左
        g.DrawLine(Pens.Black, sp.X + 8, sp.Y + 5, ep.X, ep.Y)          '下右
    End Sub
End Class