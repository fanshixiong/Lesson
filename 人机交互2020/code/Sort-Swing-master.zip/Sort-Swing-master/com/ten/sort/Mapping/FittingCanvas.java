package com.ten.sort.Mapping;

import javax.swing.*;

public class FittingCanvas extends JFrame {
}
