package com.tmall.pokemon.bulbasaur.persist.constant;

/**
 * User:  yunche.ch ... (ว ˙o˙)ง
 * Date: 15-1-8
 * Time: 下午6:16
 */
public class ProcessConstant {
    public static final String STATE_READY = "ready";
    public static final String STATE_COMPLETE = "complete";
}
