package com.flow.combination;

/**
 * @author 蔡小蔚
 */
public class String2Time {
    private String starttime;

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getStarttime() {
        return starttime;
    }
}
