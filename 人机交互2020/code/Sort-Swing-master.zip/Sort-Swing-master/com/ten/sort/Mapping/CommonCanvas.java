package com.ten.sort.Mapping;

public class CommonCanvas {
}
