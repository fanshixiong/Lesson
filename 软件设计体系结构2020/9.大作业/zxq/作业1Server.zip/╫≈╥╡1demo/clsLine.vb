﻿Public Class clsLine
    Public sp, ep As Point

    Public Sub New(ByVal sp As Point, ByVal ep As Point)
        Me.sp = sp : Me.ep = ep
    End Sub

    Public Sub Draw(ByVal g As Graphics)
        '画连线
        g.DrawLine(Pens.Black, sp.X, sp.Y, ep.X, ep.Y)
    End Sub
End Class