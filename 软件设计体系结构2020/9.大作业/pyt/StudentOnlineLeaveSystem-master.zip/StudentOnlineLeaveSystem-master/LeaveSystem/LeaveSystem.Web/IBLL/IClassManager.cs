﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LeaveSystem.Web.Models;

namespace LeaveSystem.Web.IBLL
{
    public interface IClassManager : IBaseManager<Class>
    {

    }
}