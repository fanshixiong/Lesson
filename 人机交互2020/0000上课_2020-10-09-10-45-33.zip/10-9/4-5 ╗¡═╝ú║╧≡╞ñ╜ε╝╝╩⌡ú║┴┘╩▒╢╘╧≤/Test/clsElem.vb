﻿Public MustInherit Class clsElem
    MustOverride Sub Draw(ByVal g As Graphics)
    MustOverride Sub Draw(ByVal g As Graphics, ByVal pen As Pen)

    Public Sub New()

    End Sub

End Class
