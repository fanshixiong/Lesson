
import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {


        int sceneWidth = 800;
        int sceneHeigth = 800;
        int N = 10;
        AlgoVisualizer algoVisualizer = new AlgoVisualizer(sceneWidth,sceneHeigth,N);
    }
}
