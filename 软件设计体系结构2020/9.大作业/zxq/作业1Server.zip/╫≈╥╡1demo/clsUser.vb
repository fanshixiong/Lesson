﻿Public Class clsUser
    Private ID As String
    Private password As String
    Private identity As String

    Public Sub New(ByVal id As String, ByVal pw As String, ByVal iden As String)
        Me.ID = id
        Me.password = pw
        Me.identity = iden
    End Sub

    Public Function GetID() As String
        Return Me.ID
    End Function

    Public Function GetPassword() As String
        Return Me.password
    End Function

    Public Function GetIden() As String
        Return Me.identity
    End Function

End Class
