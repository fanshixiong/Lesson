package com.tmall.pokemon.bulbasaur.persist.constant;

/**
 * User:  yunche.ch ... (ว ˙o˙)ง
 * Date: 15-1-8
 * Time: 下午6:14
 */
public class StateConstant {
    public static final String STATE_READY = "ready";
    public static final String STATE_COMPLETE = "complete";
    public static final String STATE_ROLLBACK = "rollback";
}
