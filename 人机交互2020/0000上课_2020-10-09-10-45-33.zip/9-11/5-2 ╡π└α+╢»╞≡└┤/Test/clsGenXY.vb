﻿Public Class clsGenXY
    Private x As Single, y As Single

    Public Sub New()
        x = 0 : y = 0  ' 初值
    End Sub
    Public Sub DoTick()
        x = x + 1
        y = y + 1
    End Sub
    Function GetX() As Single
        Return x
    End Function
    Function GetY() As Single
        Return y
    End Function
End Class
