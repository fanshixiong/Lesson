﻿Public MustInherit Class clsElem
    MustOverride Sub Draw(ByVal g As Graphics)

    Public Sub New()

    End Sub
End Class
