﻿Imports System.Collections.Queue

Public Class Form_Construct
    Private kind As List(Of String)
    Dim steps As List(Of Eachstep)
    Dim stepnum As Integer
    Dim identity As String
    Dim operate As String
    Dim constraint As String
    Dim eachstepitem As Eachstepitem
    Dim eachstep As Eachstep
    Dim index As Integer
    Dim frm2 As Form_Flowchart

    Private Sub Form_Construct_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Clear()
        textbox.Clear()
        tpview.Items.Clear()
        listview.Items.Clear()
        listview.Columns.Add("序号", 40, HorizontalAlignment.Center)
        listview.Columns.Add("类型名称", 80, HorizontalAlignment.Center)
        listview.View = View.Details
        listview.FullRowSelect = True
        tpview.Columns.Add("序号", 40, HorizontalAlignment.Center)
        tpview.Columns.Add("身份", 80, HorizontalAlignment.Center)
        tpview.Columns.Add("操作类型", 80, HorizontalAlignment.Center)
        tpview.Columns.Add("约束", 80, HorizontalAlignment.Center)
        tpview.View = View.Details
        tpview.FullRowSelect = True
        ComboBox1.Items.Add("提交申请")
        ComboBox1.Items.Add("审核申请")
        steps = New List(Of Eachstep)
        stepnum = 0
        index = 0
        ComboBox1.SelectedIndex = 1 '默认提交申请
        kind = New List(Of String)
    End Sub

    '点击添加用户按钮，为模板添加使用者身份
    Private Sub btnUserAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserAdd.Click
        Dim num As Integer = listview.Items.Count
        Dim userkind As String
        If (textbox.Text = Nothing) Then
            MsgBox("请填写用户身份")
        Else
            userkind = textbox.Text
            kind.Add(userkind)
            Dim item = New ListViewItem
            item.Text = CStr(num + 1)
            item.SubItems.Add(userkind)
            listview.Items.Add(item)
            textbox.Text = ""
        End If
    End Sub

    '删除模板使用者
    Private Sub deleteUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deleteUser.Click
        If (listview.SelectedItems.Count = 0) Then
            MsgBox("必须选中某行！")
        Else
            Dim str = listview.SelectedItems.Item(0).SubItems(1).Text
            kind.Remove(str)
            updateListView()
        End If
    End Sub

    Public Sub updateListView()
        listview.Items.Clear()
        For i As Integer = 0 To kind.Count - 1 Step 1
            Dim item = New ListViewItem
            item.Text = CStr(i + 1)
            item.SubItems.Add(kind(i))
            listview.Items.Add(item)
        Next
    End Sub

    '添加单支节点
    Private Sub BtnSingleAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSingleAdd.Click
        If (listview.SelectedItems.Count = 0) Then
            MsgBox("必须选中某行！")
        ElseIf (ComboBox1.SelectedIndex = -1) Then
            MsgBox("必须选中操作！")
        Else
            stepnum = stepnum + 1 '单支节点，前面序号要加1
            identity = listview.SelectedItems.Item(0).SubItems(1).Text 'listview中获取身份信息
            operate = ComboBox1.SelectedItem.ToString '组合框中获取操作信息，即提交申请or审核申请
            constraint = TextBox1.Text '获取阈值
            Dim item = New ListViewItem  '创建tpview的行
            item.Text = CStr(stepnum)
            item.SubItems.Add(identity)
            item.SubItems.Add(operate)
            item.SubItems.Add(constraint)
            tpview.Items.Add(item) '增加listview的行
            eachstepitem = New Eachstepitem(stepnum, identity, operate, constraint) '创建模板内结点子元素
            eachstep = New Eachstep(stepnum) '创建模板中新一行流程结点,第一维
            eachstep.add(eachstepitem) '将子元素添加进流程结点，第二维
            steps.Add(eachstep) '将创建的第一维结点加入模板
            ' MsgBox("添加成功")
            TextBox1.Clear()
        End If
    End Sub

    '添加分支节点
    Private Sub btnMultiAdd_Click(sender As Object, e As EventArgs) Handles btnMultiAdd.Click
        If (listview.SelectedItems.Count = 0) Then
            MsgBox("必须选中某行！")
        ElseIf (ComboBox1.SelectedIndex = -1) Then
            MsgBox("必须选中操作！")
        Else
            identity = listview.SelectedItems.Item(0).SubItems(1).Text 'listview中获取身份信息
            operate = ComboBox1.SelectedItem.ToString '组合框中获取操作信息，即提交申请or审核申请
            constraint = TextBox1.Text '获取阈值
            Dim items = New ListViewItem '创建tpview的行
            items.Text = CStr(stepnum)
            items.SubItems.Add(identity)
            items.SubItems.Add(operate)
            items.SubItems.Add(constraint)
            tpview.Items.Add(items) '增加listview的行
            eachstepitem = New Eachstepitem(stepnum, identity, operate, constraint)
            steps(stepnum - 1).eachsteplist.Add(eachstepitem) '索引比序号数小1,
            '  MsgBox("添加成功")
            TextBox1.Clear()
        End If
    End Sub

    '删除流程结点
    Private Sub deletenode_Click(sender As Object, e As EventArgs) Handles deletenode.Click
        If (tpview.SelectedItems.Count = 0) Then
            MsgBox("必须选中某行！")
        Else
            '获取选中行信息
            Dim num As Integer = CInt(tpview.SelectedItems.Item(0).SubItems(0).Text)
            Dim identity As String = tpview.SelectedItems.Item(0).SubItems(1).Text
            Dim operate As String = tpview.SelectedItems.Item(0).SubItems(2).Text
            Dim constraint As String = tpview.SelectedItems.Item(0).SubItems(3).Text
            '根据序号数找到在list中的位置
            Dim eachstep As Eachstep = steps(num - 1) '第一维的大对象
            If (eachstep.eachsteplist.Count = 1) Then '该维只有一个对象
                steps.Remove(eachstep)
                For i As Integer = 0 To steps.Count - 1 Step 1 '每次删除都对所有的序号重新表
                    steps(i).setnum(i + 1)
                Next
            Else
                For i As Integer = 0 To eachstep.eachsteplist.Count - 1 Step 1 '该维有多个对象
                    eachstepitem = eachstep.eachsteplist(i) '流程结点中的各个子元素
                    Dim tempitem As Eachstepitem = New Eachstepitem(num, identity, operate, constraint) '根据选中行创建的子元素
                    If (eachstepitem.ToString = tempitem.ToString) Then
                        eachstep.eachsteplist.Remove(eachstepitem)
                        Exit For
                    End If
                Next
            End If
            updateview() '根据steps更新tpview的显示信息
        End If
    End Sub

    Public Sub updateview()
        tpview.Items.Clear()
        For i As Integer = 0 To steps.Count - 1 Step 1
            eachstep = steps.Item(i)
            For j As Integer = 0 To eachstep.eachsteplist.Count - 1 Step 1
                eachstepitem = eachstep.eachsteplist.Item(j)
                Dim items = New ListViewItem '创建列表行对象
                items.Text = CStr(eachstepitem.stepnum) '添加行元素
                items.SubItems.Add(eachstepitem.identity)
                items.SubItems.Add(eachstepitem.operate)
                items.SubItems.Add(eachstepitem.constraint)
                tpview.Items.Add(items) '将行元素加到列表中
            Next
        Next
            stepnum = steps.Count
    End Sub

    Public Function GetKind() As String '获取返回的用户类型，字符串
        Dim str As String = Nothing
        If (kind.Count > 1) Then
            For i As Integer = 0 To kind.Count - 2 Step 1
                Str += kind(i)
                Str += "-"
            Next
            Str += kind(kind.Count - 1)
        ElseIf (kind.Count = 1) Then
            str += kind(0)
        End If
        Return str
    End Function

    '点击确定，关闭窗口
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Public Function Getsteps() As List(Of Eachstep)
        Return steps
    End Function

    '显示流程图
    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click
        frm2 = New Form_Flowchart()
        frm2.SetInfo(steps)
        frm2.ShowDialog()
    End Sub
End Class





