﻿namespace StudentOnlineLeaveSystem.Web.Models
{
    public class UserViewModel
    {
    }

}