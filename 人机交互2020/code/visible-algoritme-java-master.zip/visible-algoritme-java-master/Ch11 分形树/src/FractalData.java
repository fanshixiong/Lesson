public class FractalData {
    public int depth;
    public double spiltAngle;

    public FractalData(int depth,double spiltAngle) {
        this.depth = depth;
        this.spiltAngle = spiltAngle;
    }

    public int getDepth(){
        return depth;
    }

}
