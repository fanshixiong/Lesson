﻿Public Class Eachstep
    Public stepnum As Integer
    Public eachsteplist As List(Of Eachstepitem)

    Public Sub New()
        eachsteplist = New List(Of Eachstepitem)
    End Sub
    Public Sub New(ByVal num As Integer)
        Me.stepnum = num
        eachsteplist = New List(Of Eachstepitem)
    End Sub

    Public Sub add(ByVal one As Eachstepitem)
        eachsteplist.Add(one)
    End Sub

    Public Sub setnum(ByVal num As Integer)
        Me.stepnum = num
        For i As Integer = 0 To eachsteplist.Count - 1 Step 1
            eachsteplist.Item(i).stepnum = num
        Next
    End Sub
End Class
