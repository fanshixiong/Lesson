﻿namespace LeaveSystem.Web.IDAL
{
    //public interface IEntity<out TKey>
    //{
    //    TKey Id { get; }
    //}

}
