﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Text
Public Class Form_User
    Private s As Socket
    Private localEndPoint As IPEndPoint
    Private ID As String
    Private iden As String
    Private pw As String
    Private strs As String = Nothing
    Private frm4 As Form_apply
    Private frm5 As Form_Process

    Private Sub Form_User_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        s = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) '使用TCP协议
        localEndPoint = New IPEndPoint(IPAddress.Parse("127.0.0.1"), 8086) '指定IP和Port
        listview1.Columns.Add("学号/工号", 80, HorizontalAlignment.Center)
        listview1.Columns.Add("数目", 60, HorizontalAlignment.Center)
        listview1.Columns.Add("审批状态", 150, HorizontalAlignment.Center)
        listview1.View = View.Details
        listview1.FullRowSelect = True
    End Sub

    Public Sub SetInfo(ByVal id As String, ByVal identity As String, ByVal pw As String, ByVal str() As String)
        Me.ID = id
        Me.iden = identity
        Me.pw = pw
        UpdateInfo(str)
    End Sub

    '更新列表申请信息
    Public Sub UpdateInfo(ByVal str() As String)
        listview1.Items.Clear()
        userInfo.Text = "用户ID：" + ID + "    用户身份：" + iden
        deal.Text = str(0)
        If (str(0) = "提交申请") Then
            ifprocess.Text = "已提交的申请信息如下："
            If (str.Length > 1) Then '---------------------------注意申请人和审批人列表项的来源不同
                For i As Integer = 1 To str.Length - 1 Step 1 '添加申请信息项
                    If (str(i).Length > 0) Then
                        Dim ss() As String = str(i).Split("-")
                        Dim item = New ListViewItem
                        Dim s As String
                        If (ss(1) = Nothing) Then '身份列表为空时
                            If (ss(2) = "0") Then
                                s = "申请不在范围内"
                            Else
                                s = "审批通过"
                            End If
                        Else
                            If (ss(3) = "1") Then
                                s = "待" + ss(1) + "审批"
                            Else
                                s = ss(1) + "审批不通过"
                            End If
                        End If
                        item.Text = ID
                        item.SubItems.Add(ss(0))
                        item.SubItems.Add(s)
                        listview1.Items.Add(item)
                    End If
                Next
            End If
        Else
            ifprocess.Text = "有" + CStr(str.Length - 2) + "个待审批申请："
            For i As Integer = 1 To str.Length - 1 Step 1 '添加申请信息项
                If (str(i).Length > 0) Then
                    Dim ss() As String = str(i).Split("-")
                    Dim item = New ListViewItem
                    item.Text = CStr(ss(0))
                    item.SubItems.Add(ss(1))
                    item.SubItems.Add("待审批")
                    listview1.Items.Add(item)
                End If
            Next
        End If
    End Sub

    Public Sub SendData(ByVal str As String)
        Try
            s.Connect(localEndPoint)
            s.Send(Encoding.Unicode.GetBytes(str))
        Catch ex As Exception
        End Try
    End Sub

    '传入套接口接收数据, 建立连接并接收数据,并返回接收到的字符串
    Public Function RecvData(ByRef s As Socket, ByRef localEndPoint As IPEndPoint) As String
        Try
            Dim bytes(1024) As Byte
            's.Connect(localEndPoint) '试一试，大概前面发送时候，申请连接了，这里就不用重新连了
            Dim n As Integer = s.Receive(bytes) '接收数据
            Dim b() As Byte = TransInfo(bytes, n) '将byte数组转换为正确长度的字符串
            strs = Encoding.Unicode.GetString(b) '接收客户端传过来的用户信息
        Catch ex As Exception
        Finally
            s.Close() '先发送后接收，接收完成后，这一次交互就结束了，所以套接口可以关闭
        End Try
        Return strs
    End Function

    '点击处理按钮
    Private Sub deal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deal.Click
        Dim strs As String = Nothing
        If (deal.Text = "审核申请") Then
            If (listview1.SelectedItems.Count = 0) Then
                MsgBox("必须选中某行")
            Else
                frm5 = New Form_Process()
                frm5.ShowDialog()
                Dim flag As Integer = frm5.IfAllow() '返回0或1
                Dim id As String = listview1.SelectedItems.Item(0).SubItems(0).Text
                Dim num As String = listview1.SelectedItems.Item(0).SubItems(1).Text
                strs += "d" + CStr(flag) + iden + "-" + id + "-" + num
                SendData(strs)
                listview1.Items.Remove(listview1.SelectedItems.Item(0))
                MsgBox("审核成功！")
            End If
        Else
            frm4 = New Form_apply()
            frm4.ShowDialog()
            Dim n As Integer = frm4.GetNum()
            strs += "i" + ID + "-" + CStr(n)
            SendData(strs)
            Dim item = New ListViewItem
            item.Text = CStr(ID)
            item.SubItems.Add(CStr(n))
            item.SubItems.Add("待处理")
            listview1.Items.Add(item)
            MsgBox("提交成功！")
        End If
        'Dim mstr = RecvData(s, localEndPoint)
        'Dim str() As String = mstr.Split(",")
        'UpdateInfo(str)
    End Sub

    Private Sub btnUpdate_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim userinfo As String = "1" + ID + "-" + pw + "-" + iden '1标识说明是发送登录信息
        SendData(userinfo) '将登录信息发送给服务器
        Dim mstr = RecvData(s, localEndPoint) '接收登录后的返回信息
        Dim str() As String = mstr.Split(",")
        UpdateInfo(str)
    End Sub
End Class