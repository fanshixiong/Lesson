﻿Public Class Form_Process
    Private flag As Integer
    '审核同意
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        flag = 1
        Me.Close()
    End Sub
    '审核不同意
    Private Sub btnRefuse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefuse.Click
        flag = 0
        Me.Close()
    End Sub
    '返回选择了同意还是拒绝
    Public Function IfAllow() As Integer
        Return flag
    End Function
End Class