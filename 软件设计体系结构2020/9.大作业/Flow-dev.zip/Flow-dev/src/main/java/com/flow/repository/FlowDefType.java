package com.flow.repository;

/**
 * @author 蔡小蔚
 */

public enum FlowDefType {
    ///
    VOCATION, RECEIPT
}
