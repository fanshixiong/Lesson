package com.ten.sort.Mapping;

import javax.swing.*;

public class DerivativeCanvas extends JFrame {

}
