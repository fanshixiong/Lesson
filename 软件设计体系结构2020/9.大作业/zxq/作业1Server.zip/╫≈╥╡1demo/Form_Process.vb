﻿Public Class Form_Process

    Private Sub Form_Process_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        listview.Columns.Add("学号/工号", 80, HorizontalAlignment.Center)
        listview.Columns.Add("数目", 60, HorizontalAlignment.Center)
        listview.Columns.Add("审批状态", 150, HorizontalAlignment.Center)
        listview.View = View.Details
        listview.FullRowSelect = True
    End Sub

    Public Sub SetInfo(ByVal applications As List(Of clsApplicant), ByVal ss As Integer)
        listview.Items.Clear()
        For i As Integer = 0 To applications.Count - 1 Step 1
            Dim item = New ListViewItem
            Dim s As String
            item.Text = applications(i).GetID()
            item.SubItems.Add(CStr(applications(i).GetNum()))
            If (applications(i).IsEmpty()) Then
                If (applications(i).GetStep() + 1 < ss) Then
                    s = "申请不在范围内"
                Else
                    s = "申请通过"
                End If
            Else
                If (applications(i).GetFlag()) Then
                    s = "待" + applications(i).GetIdensToString + "审批"
                Else
                    s = applications(i).GetIdensToString + "审批不通过"
                End If
            End If
            item.SubItems.Add(s)
            listview.Items.Add(item) '增加listview的行
        Next
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

End Class