public class Main {
    public static void main(String[] args) {
        int sceneWidth = 800;
        int sceneHeight = 800;

        int N = 20;
        AlgoVisualizer visualizer = new AlgoVisualizer(sceneWidth, sceneHeight, N);

        System.out.println(1111);
    }
}


