﻿Public Class clsApplicant
    Private ID As String
    Private num As Integer
    Private identitys As List(Of String)
    Private ss As Integer
    Private flag As Integer '表示该申请是否被同意
    Public Sub New(ByVal id As String, ByVal days As Integer, ByVal idens As List(Of String), ByVal ss As Integer)
        Me.ID = id
        Me.num = days
        Me.identitys = idens
        Me.ss = ss
        Me.flag = 1 '默认为1
    End Sub

    Public Sub SetFlag()
        flag = 0
    End Sub

    Public Function GetFlag() As Integer
        Return flag
    End Function

    Public Function GetID() As String
        Return Me.ID
    End Function

    Public Function GetNum() As String
        Return Me.num
    End Function

    Public Function GetStep() As Integer
        Return ss
    End Function

    Public Sub AddStep() '升层
        ss += 1
    End Sub

    '将审批人信息转为字符串，便于传递
    Public Function GetIdensToString() As String
        Dim strs As String = Nothing
        If (identitys.Count = 1) Then
            Return identitys(0)
        ElseIf (identitys.Count > 1) Then
            For i As Integer = 0 To identitys.Count - 2 Step 1
                strs += identitys(i)
                strs += "、"
            Next
            strs += identitys(identitys.Count - 1)
        End If
        Return strs
    End Function

    '删除审批人中的一个
    Public Sub DeleteIden(ByVal iden As String)
        identitys.Remove(iden)
    End Sub

    '当前步进行完，轮到下一批审批人
    Public Sub ResetIdens(ByVal idens As List(Of String))
        identitys = idens
    End Sub

    '返回某身份是否存在
    Public Function IsApparent(ByVal iden As String) As Boolean
        For i As Integer = 0 To identitys.Count - 1 Step 1
            If (iden = identitys(i)) Then
                Return True
            End If
        Next
        Return False
    End Function

    '返回identitys是否为空
    Public Function IsEmpty() As Boolean
        If (identitys.Count = 0) Then
            Return True
        End If
        Return False
    End Function
End Class
