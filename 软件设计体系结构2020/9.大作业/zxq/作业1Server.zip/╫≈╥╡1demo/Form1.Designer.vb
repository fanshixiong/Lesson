﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnConstruct = New System.Windows.Forms.Button()
        Me.btnMainLogin = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnConstruct
        '
        Me.btnConstruct.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnConstruct.Location = New System.Drawing.Point(194, 81)
        Me.btnConstruct.Name = "btnConstruct"
        Me.btnConstruct.Size = New System.Drawing.Size(130, 44)
        Me.btnConstruct.TabIndex = 1
        Me.btnConstruct.Text = "构建模板"
        Me.btnConstruct.UseVisualStyleBackColor = True
        '
        'btnMainLogin
        '
        Me.btnMainLogin.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnMainLogin.Location = New System.Drawing.Point(194, 268)
        Me.btnMainLogin.Name = "btnMainLogin"
        Me.btnMainLogin.Size = New System.Drawing.Size(130, 44)
        Me.btnMainLogin.TabIndex = 0
        Me.btnMainLogin.Text = "流程信息"
        Me.btnMainLogin.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnStart.Location = New System.Drawing.Point(194, 146)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(130, 43)
        Me.btnStart.TabIndex = 2
        Me.btnStart.Text = "启用服务"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnStop.Location = New System.Drawing.Point(194, 207)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(130, 43)
        Me.btnStop.TabIndex = 3
        Me.btnStop.Text = "关闭服务"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(507, 365)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.btnConstruct)
        Me.Controls.Add(Me.btnMainLogin)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnConstruct As System.Windows.Forms.Button
    Friend WithEvents btnMainLogin As System.Windows.Forms.Button
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents btnStop As System.Windows.Forms.Button

End Class
