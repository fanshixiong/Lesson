﻿Public Class Eachstepitem
    Public stepnum As Integer '步骤号
    Public identity As String '事件响应者身份
    Public operate As String '操作
    Public constraint As String

    Public Sub New(ByVal s As Integer, ByVal i As String, ByVal o As String, ByVal c As String)
        Me.stepnum = s
        Me.identity = i
        Me.operate = o
        Me.constraint = c
    End Sub

End Class
