﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form_Construct
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.listview = New System.Windows.Forms.ListView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.textbox = New System.Windows.Forms.TextBox()
        Me.btnUserAdd = New System.Windows.Forms.Button()
        Me.BtnSingleAdd = New System.Windows.Forms.Button()
        Me.btnMultiAdd = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tpview = New System.Windows.Forms.ListView()
        Me.deletenode = New System.Windows.Forms.Button()
        Me.deleteUser = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'listview
        '
        Me.listview.Location = New System.Drawing.Point(18, 44)
        Me.listview.Name = "listview"
        Me.listview.Size = New System.Drawing.Size(290, 151)
        Me.listview.TabIndex = 0
        Me.listview.UseCompatibleStateImageBehavior = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label1.Location = New System.Drawing.Point(309, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "添加用户类型"
        '
        'textbox
        '
        Me.textbox.Location = New System.Drawing.Point(332, 56)
        Me.textbox.Name = "textbox"
        Me.textbox.Size = New System.Drawing.Size(100, 28)
        Me.textbox.TabIndex = 2
        '
        'btnUserAdd
        '
        Me.btnUserAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUserAdd.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnUserAdd.Location = New System.Drawing.Point(444, 49)
        Me.btnUserAdd.Name = "btnUserAdd"
        Me.btnUserAdd.Size = New System.Drawing.Size(132, 46)
        Me.btnUserAdd.TabIndex = 3
        Me.btnUserAdd.Text = "添加用户"
        Me.btnUserAdd.UseVisualStyleBackColor = True
        '
        'BtnSingleAdd
        '
        Me.BtnSingleAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSingleAdd.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.BtnSingleAdd.Location = New System.Drawing.Point(468, 353)
        Me.BtnSingleAdd.Name = "BtnSingleAdd"
        Me.BtnSingleAdd.Size = New System.Drawing.Size(184, 51)
        Me.BtnSingleAdd.TabIndex = 4
        Me.BtnSingleAdd.Text = "添加单支节点"
        Me.BtnSingleAdd.UseVisualStyleBackColor = True
        '
        'btnMultiAdd
        '
        Me.btnMultiAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMultiAdd.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnMultiAdd.Location = New System.Drawing.Point(468, 423)
        Me.btnMultiAdd.Name = "btnMultiAdd"
        Me.btnMultiAdd.Size = New System.Drawing.Size(184, 51)
        Me.btnMultiAdd.TabIndex = 5
        Me.btnMultiAdd.Text = "添加分支节点"
        Me.btnMultiAdd.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(565, 306)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(134, 28)
        Me.TextBox1.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label2.Location = New System.Drawing.Point(440, 308)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 24)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "约束条件"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label3.Location = New System.Drawing.Point(440, 261)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 24)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "操作类型"
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(565, 260)
        Me.ComboBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(134, 26)
        Me.ComboBox1.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label4.Location = New System.Drawing.Point(18, 223)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(154, 24)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "模板顺序列表"
        '
        'tpview
        '
        Me.tpview.Location = New System.Drawing.Point(18, 250)
        Me.tpview.Name = "tpview"
        Me.tpview.Size = New System.Drawing.Size(414, 343)
        Me.tpview.TabIndex = 12
        Me.tpview.UseCompatibleStateImageBehavior = False
        '
        'deletenode
        '
        Me.deletenode.Cursor = System.Windows.Forms.Cursors.Hand
        Me.deletenode.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.deletenode.Location = New System.Drawing.Point(496, 553)
        Me.deletenode.Margin = New System.Windows.Forms.Padding(4)
        Me.deletenode.Name = "deletenode"
        Me.deletenode.Size = New System.Drawing.Size(122, 50)
        Me.deletenode.TabIndex = 13
        Me.deletenode.Text = "删除节点"
        Me.deletenode.UseVisualStyleBackColor = True
        '
        'deleteUser
        '
        Me.deleteUser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.deleteUser.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.deleteUser.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.deleteUser.Location = New System.Drawing.Point(444, 108)
        Me.deleteUser.Name = "deleteUser"
        Me.deleteUser.Size = New System.Drawing.Size(132, 43)
        Me.deleteUser.TabIndex = 14
        Me.deleteUser.Text = "删除用户"
        Me.deleteUser.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOK.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnOK.Location = New System.Drawing.Point(690, 580)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(96, 39)
        Me.btnOK.TabIndex = 15
        Me.btnOK.Text = "确定"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label5.Location = New System.Drawing.Point(18, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(106, 24)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "用户类型"
        '
        'btnShow
        '
        Me.btnShow.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShow.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.btnShow.Location = New System.Drawing.Point(484, 490)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(145, 46)
        Me.btnShow.TabIndex = 17
        Me.btnShow.Text = "显示流程图"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'Form_Construct
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(788, 621)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.deleteUser)
        Me.Controls.Add(Me.deletenode)
        Me.Controls.Add(Me.tpview)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnMultiAdd)
        Me.Controls.Add(Me.BtnSingleAdd)
        Me.Controls.Add(Me.btnUserAdd)
        Me.Controls.Add(Me.textbox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.listview)
        Me.Name = "Form_Construct"
        Me.Text = "Form_Construct"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents listview As System.Windows.Forms.ListView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents textbox As System.Windows.Forms.TextBox
    Friend WithEvents btnUserAdd As System.Windows.Forms.Button
    Friend WithEvents BtnSingleAdd As System.Windows.Forms.Button
    Friend WithEvents btnMultiAdd As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents tpview As ListView
    Friend WithEvents deletenode As Button
    Friend WithEvents deleteUser As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnShow As System.Windows.Forms.Button
End Class
